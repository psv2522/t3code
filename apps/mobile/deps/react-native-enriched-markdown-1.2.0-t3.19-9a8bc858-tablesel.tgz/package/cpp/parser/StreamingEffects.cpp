#include "StreamingEffects.hpp"
#include "StreamingWords.hpp"

#include <algorithm>

namespace Markdown {

namespace {

// The gradient settles to the characters' own colors this long after the stream ends.
constexpr double kSettleDuration = 0.2;
// The gradient reaches new text by the time more usually arrives: the usual gap between growths,
// kept between these, so it neither jumps nor stops between words.
constexpr double kMinGlide = 0.05;
constexpr double kMaxGlide = 0.25;

float easeOut(double progress) {
  double clamped = std::clamp(progress, 0.0, 1.0);
  return static_cast<float>(1.0 - (1.0 - clamped) * (1.0 - clamped));
}

EffectColor mix(const EffectColor &from, const EffectColor &to, float amount) {
  return {from.r + (to.r - from.r) * amount, from.g + (to.g - from.g) * amount, from.b + (to.b - from.b) * amount,
          from.a + (to.a - from.a) * amount};
}

// A transparent end keeps the hue of the color it fades from.
EffectColor transparentLike(const EffectColor &color) {
  return {color.r, color.g, color.b, 0};
}

} // namespace

void StreamingEffects::configure(const StreamingEffectConfig &config) {
  config_ = config;
  // A fade over no time, or a gradient over no characters, is no effect.
  if ((config_.type == StreamingEffectType::Fade && !(config_.duration > 0)) ||
      (config_.type == StreamingEffectType::Gradient && config_.length == 0)) {
    config_.type = StreamingEffectType::None;
  }
  reset();
}

void StreamingEffects::noteArrival(size_t start, size_t end, double time, std::u16string_view text, char16_t previous) {
  // Text arriving after it settled streams on its own, and settled text stays as it is.
  if (end > textLength_ && finishedAt_) {
    settledFloor_ = settledEnd_;
    settledGradientEnd_ = std::max(gradientEnd(time), static_cast<double>(settledEnd_));
    settledEnd_ = textLength_;
    settledAt_ = finishedAt_;
  }
  settledEnd_ = std::min(settledEnd_, end);
  settledFloor_ = std::min(settledFloor_, end);
  if (end != textLength_) {
    double now = std::max(gradientEnd(time), static_cast<double>(settledEnd_));
    if (end > textLength_) {
      if (lastGrowth_ && time > *lastGrowth_) {
        double gap = std::clamp(time - *lastGrowth_, kMinGlide, kMaxGlide);
        growthGap_ = growthGap_ > 0 ? growthGap_ * 0.7 + gap * 0.3 : gap;
      }
      lastGrowth_ = time;
    }
    // From where it is now, at most its own length behind: a whole document arriving at once doesn't sweep.
    glideFrom_ = std::max(std::min(now, static_cast<double>(end)),
                          end > config_.length ? static_cast<double>(end - config_.length) : 0.0);
    glideStart_ = time;
    double glide = growthGap_ > 0 ? growthGap_ : kMaxGlide;
    glideSpeed_ = (static_cast<double>(end) - glideFrom_) / glide;
  }
  if (end < textLength_) {
    units_.erase(std::remove_if(units_.begin(), units_.end(), [&](const Unit &unit) { return unit.start >= end; }),
                 units_.end());
    if (!units_.empty()) {
      units_.back().end = std::min(units_.back().end, end);
    }
  }
  textLength_ = end;
  if (end <= start) {
    return;
  }
  finishedAt_.reset();
  if (config_.type != StreamingEffectType::Fade) {
    return;
  }
  prune(time);
  if (text.size() != end - start) {
    units_.push_back({start, end, time});
    return;
  }
  size_t i = 0;
  // Spaces, or the rest of a word the last chunk ended inside, go with that word; when it has
  // already appeared, they show at once.
  bool continues =
      isStreamingSpace(text[0]) || (!isStreamingSpace(previous) && !isOwnWord(previous) && !isOwnWord(text[0]));
  if (continues) {
    if (isStreamingSpace(text[0])) {
      while (i < text.size() && isStreamingSpace(text[i])) {
        i++;
      }
    } else {
      i = wordEnd(text, 0);
    }
    if (!units_.empty() && units_.back().end == start) {
      units_.back().end = start + i;
    }
  }
  while (i < text.size()) {
    size_t next = wordEnd(text, i);
    units_.push_back({start + i, start + next, time});
    i = next;
  }
}

void StreamingEffects::finish(double time) {
  if (!finishedAt_) {
    finishedAt_ = time;
  }
}

void StreamingEffects::reset() {
  units_.clear();
  textLength_ = 0;
  glideFrom_ = 0;
  glideStart_ = 0;
  glideSpeed_ = 0;
  growthGap_ = 0;
  lastGrowth_.reset();
  finishedAt_.reset();
  settledEnd_ = 0;
  settledAt_.reset();
  settledGradientEnd_ = 0;
  settledFloor_ = 0;
}

bool StreamingEffects::settling(double time) const {
  return settledAt_ && time - *settledAt_ < kSettleDuration;
}

void StreamingEffects::prune(double time) {
  auto settled =
      std::find_if(units_.begin(), units_.end(), [&](const Unit &unit) { return time - unit.time < config_.duration; });
  units_.erase(units_.begin(), settled);
}

const StreamingEffects::Unit *StreamingEffects::unitAt(size_t index) const {
  auto after =
      std::upper_bound(units_.begin(), units_.end(), index, [](size_t i, const Unit &unit) { return i < unit.start; });
  if (after == units_.begin()) {
    return nullptr;
  }
  const Unit &unit = *std::prev(after);
  return index < unit.end ? &unit : nullptr;
}

size_t StreamingEffects::lookEnd(size_t index) const {
  if (config_.type == StreamingEffectType::Gradient) {
    return index + 1;
  }
  auto after =
      std::upper_bound(units_.begin(), units_.end(), index, [](size_t i, const Unit &unit) { return i < unit.start; });
  if (after != units_.begin() && index < std::prev(after)->end) {
    // The words that arrived with it follow it.
    auto unit = std::prev(after);
    while (after != units_.end() && after->start == unit->end && after->time == unit->time) {
      unit = after++;
    }
    return unit->end;
  }
  return after != units_.end() ? after->start : std::max(textLength_, index + 1);
}

double StreamingEffects::gradientEnd(double time) const {
  double end = static_cast<double>(textLength_);
  if (glideFrom_ >= end) {
    return end;
  }
  return std::min(end, glideFrom_ + glideSpeed_ * std::max(0.0, time - glideStart_));
}

bool StreamingEffects::changesOverTime(double time) {
  if (config_.type == StreamingEffectType::Gradient) {
    if (finishedAt_) {
      return time - *finishedAt_ < kSettleDuration;
    }
    return settling(time) || (textLength_ > 0 && gradientEnd(time) < static_cast<double>(textLength_));
  }
  return animatedRange(time).has_value();
}

std::optional<CharacterRange> StreamingEffects::animatedRange(double time) {
  if (textLength_ == 0) {
    return std::nullopt;
  }
  switch (config_.type) {
    case StreamingEffectType::Gradient: {
      if (finishedAt_ && time - *finishedAt_ >= kSettleDuration) {
        return std::nullopt;
      }
      auto end = static_cast<size_t>(gradientEnd(time));
      size_t start = std::max(end > config_.length ? end - config_.length : 0, settledEnd_);
      // What settled before the new text still finishes settling, from where its gradient ended.
      if (settling(time)) {
        auto settledFrom = static_cast<size_t>(settledGradientEnd_);
        start =
            std::min(start, std::max(settledFloor_, settledFrom > config_.length ? settledFrom - config_.length : 0));
      }
      if (start >= textLength_) {
        return std::nullopt;
      }
      return CharacterRange{start, textLength_ - start};
    }
    case StreamingEffectType::Fade: {
      prune(time);
      if (units_.empty()) {
        return std::nullopt;
      }
      size_t start = std::min(units_.front().start, textLength_);
      return CharacterRange{start, std::min(units_.back().end, textLength_) - start};
    }
    case StreamingEffectType::None:
      return std::nullopt;
  }
  return std::nullopt;
}

CharacterLook StreamingEffects::lookAt(size_t index, double time) const {
  CharacterLook look;
  if (config_.type == StreamingEffectType::Fade) {
    if (const Unit *unit = unitAt(index)) {
      look.opacity = easeOut((time - unit->time) / config_.duration);
    }
    return look;
  }
  if (config_.type != StreamingEffectType::Gradient) {
    return look;
  }
  // Text that settled before new text arrived finishes settling where its gradient ended.
  bool settled = index < settledEnd_;
  if (index < settledFloor_ || (settled && !settling(time))) {
    return look;
  }
  double gradientEnds = settled ? settledGradientEnd_ : gradientEnd(time);
  std::optional<double> settleStart = settled ? settledAt_ : finishedAt_;
  // 0 for the newest character (and any the glide hasn't reached), 1 for the first one past the
  // gradient; fractional while it glides.
  double fromEnd = std::max(0.0, gradientEnds - 1.0 - static_cast<double>(index));
  float position = std::min(1.0f, static_cast<float>(fromEnd / static_cast<double>(config_.length)));
  const auto &start = config_.startColor;
  const auto &end = config_.endColor;
  if (start) {
    // One color for the whole tail, the character's own color left behind.
    EffectColor to = end && end->a > 0 ? *end : transparentLike(*start);
    look.tint = mix(to, *start, position);
    look.tintAmount = 1;
  } else if (end && end->a > 0) {
    look.tint = *end;
    look.tintAmount = 1 - position;
  } else {
    look.opacity = position;
  }
  if (settleStart) {
    float settle = easeOut((time - *settleStart) / kSettleDuration);
    look.tintAmount *= 1 - settle;
    look.opacity += (1 - look.opacity) * settle;
  }
  return look;
}

} // namespace Markdown
